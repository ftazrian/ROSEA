// $('.catagory-part2').slick({
//     infinite: true,
//     slidesToShow: 8,
//     slidesToScroll: 1,
//     autoplay: true,
//     autoplaySpeed: 2000,
   
    
//     cssEase: 'linear',

//     responsive: [

//         {
//         breakpoint: 600,
//             settings: {
//                 slidesToShow: 2,
//                 slidesToScroll: 2
//             }
//         },
//         {
//         breakpoint: 480,
//             settings: {
//                 slidesToShow: 1,
//                 slidesToScroll: 1
//             }
//         }
//         // You can unslick at a given breakpoint now by adding:
//         // settings: "unslick"
//         // instead of a settings object
//     ]
// });

// $('.another-catagory').slick({
//     infinite: true,
//     slidesToShow: 4,
//     slidesToScroll: 1,
//     autoplay: true,
//     autoplaySpeed: 2000,
   
    
//     cssEase: 'linear',

//     responsive: [

//         {
//         breakpoint: 800,
//             settings: {
//                 slidesToShow: 3,
//                 slidesToScroll: 1
//             }
//         },
//         {
//         breakpoint: 500,
//             settings: {
//                 slidesToShow: 1,
//                 slidesToScroll: 1
//             }
//         }
       
//     ]
// });


$('.first-slider').slick({
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 1000,
 
  
  cssEase: 'linear',
  responsive: [

      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        }
      }
     

    ]

 
});

$('.second-slider').slick({
  infinite: true,
  slidesToShow: 2,
  slidesToScroll: 1,
  // autoplay: true,
  // autoplaySpeed: 1000,
 
  
  cssEase: 'linear',
  responsive: [

      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        }
      }
     

    ]

 
});


$('.banner-slide').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
   
    
    cssEase: 'linear',

   
});

const faqs = document.querySelectorAll(".faq");

faqs.forEach(faq => {
    faq.addEventListener("click", () => {
        faq.classList.toggle("active");
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.getElementById("toggle-button");
    const hiddenContent = document.querySelector(".hidden-content");

    toggleButton.addEventListener("click", function () {
        if (hiddenContent.style.display === "none" || hiddenContent.style.display === "") {
            hiddenContent.style.display = "block";
            toggleButton.textContent = "Read Less";
        } else {
            hiddenContent.style.display = "none";
            toggleButton.textContent = "Read More";
        }
    });
});


// $(document).ready(function(){
      
  
//     $(".another-catagory").slick({
//       infinite: true,
//       slidesToShow: 5,
//       slidesToScroll: 1,
//       autoplay: true,
//       autoplaySpeed: 1000,
//       arrows:false,
//       pauseOnHover:false,
   
//       responsive: [
  
//           {
//           breakpoint: 768,
//               settings: {
//                   slidesToShow: 4,
//               }
//           },
//           {
//           breakpoint: 520,
//               settings: {
//                   slidesToShow: 3,
//               }
//           }
         
//       ]
//   });
// });
// 
// $('.cart-section').slick({
//   infinite: true,
//   slidesToShow: 4,
//   slidesToScroll: 1,
//   autoplay: true,
//   autoplaySpeed: 10000,
  
 
  
//   cssEase: 'linear',

//   responsive: [
//     {
//       breakpoint: 1400,
//           settings: {
//               slidesToShow: 4,
//               slidesToScroll: 1,
//               // dots:true,
//           }
//       },
//       {
//         breakpoint: 1000,
//             settings: {
//                 slidesToShow: 3,
//                 slidesToScroll: 1,
//                 dots:true,
//             }
//         },

//       {
//       breakpoint: 800,
//           settings: {
//               slidesToShow: 2,
//               slidesToScroll: 1,
//               dots:true,
//           }
//       },
//       {
//       breakpoint: 500,
//           settings: {
//               slidesToShow: 1,
//               slidesToScroll: 1,
//               dots:true,
//           }
//       }
     
//   ]
// });


$(document).ready(function () {


  $(".another-catagory-product-3").slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    arrows: false,
    pauseOnHover: false,
    

    responsive: [

      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          dots:true,
        }
      },
      {
        breakpoint: 520,
        settings: {
          slidesToShow: 1,
          dots:true,
        }
      }

    ]
  });
});

$(document).ready(function () {


  $(".brand-images-div").slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 10000,
      arrows: false,
      pauseOnHover: false,
      dots:true,

      responsive: [

          {
              breakpoint: 1000,
              settings: {
                  slidesToShow: 3,
              }
          },
          {
              breakpoint: 700,
              settings: {
                  slidesToShow: 1,
              }
          },
          {
            breakpoint: 450,
            settings: {
                slidesToShow: 1,
            }
        }

      ]
  });
});



